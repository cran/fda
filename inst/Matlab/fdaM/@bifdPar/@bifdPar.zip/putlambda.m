function putlambda(lambda, bifdParobj)
%  Replace the lambda parameters

bifdParobj.lambdas = lambda(1);
bifdParobj.lambdat = lambda(2);
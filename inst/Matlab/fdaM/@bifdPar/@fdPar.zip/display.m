function display(fdPar)
fprintf('\nFD:\n');
display(fdPar.fd);
fprintf('\nestimate = %d\n', fdPar.estimate);
display(fdPar.estimate);
fprintf('\nLfd:\n');
display(fdPar.Lfd);
fprintf('\nlambda = %.6g\n');
display(fdPar.lambda);

